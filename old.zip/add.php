<?php
include 'config.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $ingredients = $_POST['ingredients'];
    $instructions = $_POST['instructions'];
    $imagePath = null;

    // Handle image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxSize = 2 * 1024 * 1024; // 2MB
        $fileType = $_FILES['image']['type'];
        $fileSize = $_FILES['image']['size'];

        if (in_array($fileType, $allowedTypes) && $fileSize <= $maxSize) {
            $fileName = uniqid() . '_' . basename($_FILES['image']['name']);
            $targetPath = 'uploads/' . $fileName;
            if (move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
                $imagePath = $targetPath;
            } else {
                $message = 'Error uploading image.';
            }
        } else {
            $message = 'Invalid image type or size (max 2MB, JPEG/PNG/GIF only).';
        }
    }

    if (!$message) {
        $stmt = $conn->prepare(" INSERT INTO recipes (title, ingredients, instructions, image) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $title, $ingredients, $instructions, $imagePath);
        $stmt->execute();
        header("Location: index.php");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Recipe</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Add Recipe</h1>
    <?php if ($message): ?><p style="color: blue;"><?php echo $message; ?></p><?php endif; ?>
    <form method="post" enctype="multipart/form-data">
        <label>Title: <input type="text" name="title" required></label><br>
        <label>Ingredients: <textarea name="ingredients" required></textarea></label><br>
        <label>Instructions: <textarea name="instructions" required></textarea></label><br>
        <label>Image (optional): <input type="file" name="image" accept="image/*" id="imageInput"></label><br>
        <div id="imagePreview" style="margin: 10px 0; display: none;">
            <img id="previewImg" src="" alt="Image Preview" style="max-width: 300px; height: auto; border: 1px solid #ccc;">
        </div>
        <button type="submit">Add</button>
    </form>
    <a href="index.php">Back</a>

    <script>
        // JavaScript for image preview
        document.getElementById('imageInput').addEventListener('change', function(event) {
            const file = event.target.files[0];
            const preview = document.getElementById('imagePreview');
            const img = document.getElementById('previewImg');
            
            if (file && file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    img.src = e.target.result;
                    preview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            } else {
                preview.style.display = 'none';
            }
        });
    </script>
</body>
</html>
