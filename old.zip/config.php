<?php
$host = 'localhost';
$user = 'root'; // Default XAMPP user
$pass = ''; // Default XAMPP password
$db = 'recipe_book';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>