<?php
include 'config.php';
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM recipes WHERE id = $id");
$recipe = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $ingredients = $_POST['ingredients'];
    $instructions = $_POST['instructions'];
    $stmt = $conn->prepare("UPDATE recipes SET title=?, ingredients=?, instructions=? WHERE id=?");
    $stmt->bind_param("sssi", $title, $ingredients, $instructions, $id);
    $stmt->execute();
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Recipe</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Edit Recipe</h1>
    <form method="post">
        <label>Title: <input type="text" name="title" value="<?php echo htmlspecialchars($recipe['title']); ?>" required></label><br>
        <label>Ingredients: <textarea name="ingredients" required><?php echo htmlspecialchars($recipe['ingredients']); ?></textarea></label><br>
        <label>Instructions: <textarea name="instructions" required><?php echo htmlspecialchars($recipe['instructions']); ?></textarea></label><br>
        <button type="submit">Update</button>
    </form>
    <a href="index.php">Back</a>
</body>
</html>