CREATE DATABASE recipe_book;
USE recipe_book;

CREATE TABLE recipes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    ingredients TEXT NOT NULL,
    instructions TEXT NOT NULL,
	image VARCHAR(500)            
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
