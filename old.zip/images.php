<?php
include 'config.php';
$id = $_GET['id'];
$result = $conn->query("SELECT image FROM recipes WHERE id = $id");
$recipe = $result->fetch_assoc();

// Delete image file if exists
if ($recipe['image'] && file_exists($recipe['image'])) {
    unlink($recipe['image']);
}

$conn->query("DELETE FROM recipes WHERE id = $id");
header("Location: index.php");
?>
