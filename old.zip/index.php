<?php
include 'config.php';
$result = $conn->query("SELECT * FROM recipes ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Old Recipe Book</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Old Recipe Book</h1>
    <a href="add.php">Add New Recipe</a>
    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="recipe">
            <h2><?php echo htmlspecialchars($row['title']); ?></h2>
            <?php if ($row['image']): ?>
                <img src="<?php echo htmlspecialchars($row['image']); ?>" alt="Recipe Image" style="max-width: 300px; height: auto; margin: 10px 0;">
            <?php endif; ?>
            <p><strong>Ingredients:</strong> <?php echo nl2br(htmlspecialchars($row['ingredients'])); ?></p>
            <p><strong>Instructions:</strong> <?php echo nl2br(htmlspecialchars($row['instructions'])); ?></p>
            <a href="edit.php?id=<?php echo $row['id']; ?>">Edit</a> | 
            <a href="delete.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Delete?')">Delete</a>
        </div>
    <?php endwhile; ?>
</body>
</html>
